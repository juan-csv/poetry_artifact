pip install git+https://github.com/juan-csv/poetry_artifact.git#v0.1.0 --user
pip install git+https://github.com/juan-csv/poetry_artifact.git#egg=poetry_artifact --user
